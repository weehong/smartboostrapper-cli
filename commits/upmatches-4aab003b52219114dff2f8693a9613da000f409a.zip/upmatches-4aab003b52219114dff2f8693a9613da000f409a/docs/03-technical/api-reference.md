# API Reference

This document covers high-level API concepts such as Authentication and Error Handling. Specific endpoints are documented via Swagger/OpenAPI.

## Authentication
<!-- Describe authentication mechanism (e.g., JWT, OAuth2) -->

## Error Handling
<!-- Describe standard error responses and codes -->

## Database Configuration API

### Configuration Classes

#### DatabaseConfiguration
The main configuration class that creates and configures the HikariCP DataSource.

**Annotations:**
- `@Configuration(proxyBeanMethods = false)`: Configuration class without proxy methods
- `@ConditionalOnProperty`: Only enabled when `app.database.enabled=true`

**Primary Bean:**
```java
@Bean
@Primary
@ConditionalOnProperty(
    prefix = "app.database",
    name = "enabled",
    havingValue = "true",
    matchIfMissing = true
)
public DataSource dataSource()
```

#### DatabaseProperty
Configuration properties for database connection.

**Annotations:**
- `@ConfigurationProperties(prefix = "spring.datasource")`: Binds to `spring.datasource.*`
- `@Component`: Spring component for dependency injection

**Properties:**
```java
private String url;                    // JDBC URL
private String username;              // Database username
private String password;              // Database password
private String driverClassName;       // Optional driver class
private HikariProperty hikari;        // HikariCP properties
```

#### HikariProperty
Nested configuration properties for HikariCP connection pool.

**Properties:**
```java
private Integer maximumPoolSize;      // Maximum pool size
private Integer minimumIdle;          // Minimum idle connections
private Long idleTimeout;             // Idle timeout in milliseconds
private Long maxLifetime;             // Maximum connection lifetime
private Long connectionTimeout;       // Connection timeout
private Long leakDetectionThreshold;  // Leak detection threshold
private Long initializationFailTimeout; // Initialization fail timeout
```

### Constants

#### DatabaseConstants
Utility class containing default values and JDBC URL prefixes.

**Key Constants:**
```java
public static final String JDBC_H2 = "jdbc:h2:";
public static final String JDBC_POSTGRESQL = "jdbc:postgresql:";
public static final String JDBC_MYSQL = "jdbc:mysql:";
public static final String DEFAULT_POOL_NAME = "hikari-pool";
public static final String DEFAULT_APPLICATION_NAME = "upmatches";
public static final int DEFAULT_MAXIMUM_POOL_SIZE = 10;
public static final int DEFAULT_MINIMUM_IDLE = 10;
public static final long DEFAULT_CONNECTION_TIMEOUT = TimeUnit.SECONDS.toMillis(30);
public static final long DEFAULT_IDLE_TIMEOUT = TimeUnit.MINUTES.toMillis(10);
public static final long DEFAULT_MAX_LIFETIME = TimeUnit.MINUTES.toMillis(30);
public static final long DEFAULT_INITIALIZATION_FAIL_TIMEOUT = TimeUnit.SECONDS.toMillis(30);
```

### Enums

#### DatabaseType
Enumeration of supported database types with URL prefix and driver class mapping.

**Methods:**
```java
public static DatabaseType fromJdbcUrl(String jdbcUrl)
public String getPrefix()
public String getDriverClassName()
```

**Values:**
- `H2`: Prefix `"jdbc:h2:"`, Driver `"org.h2.Driver"`
- `POSTGRESQL`: Prefix `"jdbc:postgresql:"`, Driver `"org.postgresql.Driver"`
- `MYSQL`: Prefix `"jdbc:mysql:"`, Driver `"com.mysql.cj.jdbc.Driver"`

### Configuration Flow

```mermaid
sequenceDiagram
    participant App as Application
    participant Config as DatabaseConfiguration
    participant Props as DatabaseProperty
    participant Hikari as HikariCP
    participant DB as Database
    
    App->>Config: Request DataSource
    Config->>Props: Get database properties
    Props-->>Config: Return URL, credentials
    Config->>Config: Validate URL
    Config->>Config: Detect database type
    Config->>Config: Apply optimizations
    Config->>Hikari: Create HikariConfig
    Hikari->>DB: Establish connections
    Hikari-->>Config: Return DataSource
    Config-->>App: Return configured DataSource
```

### Dependency Injection

The configuration uses constructor injection for dependencies:

```java
public DatabaseConfiguration(DatabaseProperty databaseProperty,
                             Environment environment,
                             Optional<MeterRegistry> meterRegistry)
```

**Dependencies:**
1. `DatabaseProperty`: Database configuration properties
2. `Environment`: Spring environment for profile detection
3. `Optional<MeterRegistry>`: Optional metrics registry for monitoring

### Testing API

#### DatabaseConfigurationTest
Comprehensive test suite for database configuration.

**Test Categories:**
1. **DataSource Creation Tests**: Validates DataSource bean creation
2. **Database Type Detection**: Tests URL parsing and type detection
3. **Property Resolution**: Tests configuration property binding
4. **Error Scenarios**: Tests exception handling
5. **Optimization Tests**: Validates database-specific optimizations

**Key Test Methods:**
```java
@Test
void dataSource_nullUrl_throwsIllegalStateException()

@Test
void dataSource_h2Url_createsDataSourceSuccessfully()

@Test
void dataSource_postgresqlUrl_createsDataSourceSuccessfully()

@Test
void getDriverClassName_unsupportedUrl_throwsIllegalArgumentException()
```

### Integration Points

#### Spring Boot Auto-configuration
The configuration integrates with Spring Boot's auto-configuration:
- Uses `@ConditionalOnProperty` for conditional bean creation
- Integrates with Spring's property resolution
- Works with Spring profiles

#### Micrometer Integration
```java
meterRegistry.ifPresent(reg -> {
    config.setMetricsTrackerFactory(new MicrometerMetricsTrackerFactory(reg));
    LOGGER.info("Metrics enabled with {}", reg.getClass().getSimpleName());
});
```

#### Actuator Integration
When Spring Boot Actuator is enabled, database health checks are automatically configured through the `DataSourceHealthIndicator`.

### Extension Points

#### Adding New Database Support
1. Add new constant to `DatabaseConstants`
2. Add new enum value to `DatabaseType`
3. Implement database-specific optimizations in `applyDatabaseOptimizations()` method
4. Update tests to cover new database type

#### Custom Configuration
Override or extend the configuration by:
1. Creating a custom `@Configuration` class
2. Using `@Primary` to override the default DataSource
3. Extending `DatabaseProperty` for additional properties
4. Implementing custom connection validation
