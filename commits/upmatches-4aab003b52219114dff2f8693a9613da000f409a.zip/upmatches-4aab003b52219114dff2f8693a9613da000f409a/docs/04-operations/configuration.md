# Application Configuration

The system uses Spring Boot's externalized configuration and supports multiple environments via YAML profiles and environment variables.

**Main Configuration File:** `src/main/resources/application.yaml`
```yaml
server:
  port: ${SERVER_PORT:8080}
spring:
  application:
    name: ${APPLICATION_NAME:upmatches}
```

**Test Configuration:** `src/test/resources/application-test.yaml`
```yaml
server:
  port: ${SERVER_PORT:0}  # Random port for tests
spring:
  application:
    name: ${APPLICATION_NAME:upmatches}
```

## Environment Variables

| Variable | Default | Purpose |
|----------|---------|---------|
| `SERVER_PORT` | 8080 | Application server port |
| `APPLICATION_NAME` | upmatches | Spring application name |
| `GITHUB_USERNAME` | - | GitHub Packages authentication |
| `GITHUB_TOKEN` | - | GitHub Packages token |
| `SONAR_TOKEN` | - | SonarCloud authentication |
| `DOCKERHUB_USERNAME`| - | Docker Hub username |
| `DOCKERHUB_PASSWORD`| - | Docker Hub password |
| `GF_SECURITY_ADMIN_USER` | vernon | Grafana admin username |
| `GF_SECURITY_ADMIN_PASSWORD` | password | Grafana admin password |
| `K6_PROMETHEUS_RW_SERVER_URL` | http://prometheus:9090/api/v1/write | k6 Prometheus remote write URL |
| `LOKI_ENABLED` | false | Enable Loki logging |
| `LOKI_URL` | http://localhost:3100/loki/api/v1/push | Loki push API URL |
| `LOKI_BATCH_SIZE` | 1000 | Loki log batch size |
| `LOKI_BATCH_TIMEOUT` | 5000 | Loki log batch timeout (ms) |
| `TRACING_ENABLED` | false | Enable distributed tracing |
| `TRACING_SAMPLING_PROBABILITY` | 1.0 | Tracing sampling probability (0.0 to 1.0) |
| `TRACING_OTLP_ENDPOINT` | http://localhost:4317 | OTLP gRPC endpoint for tracing |

## Profiles

- **default**: Standard configuration for development.
- **test**: Activated during test execution using `@ActiveProfiles("test")`.

## Feature Configuration

### Logging Aspect
A configuration namespace `app.logging.aspect` manages Aspect-Oriented Programming (AOP) behavior for logging.

**Location:** `src/main/resources/application.yaml`
```yaml
app:
  logging:
    aspect:
      enabled: true               # Master switch for AOP logging
      slow-execution-threshold-ms: 1000  # Threshold for logging slow method executions
```

### Loki Logging
Configuration for sending logs directly to Grafana Loki.

**Location:** `src/main/resources/application.yaml`
```yaml
app:
  logging:
    loki:
      enabled: false
      url: http://localhost:3100/loki/api/v1/push
      batch-size: 1000
```

### Distributed Tracing
Configuration for OTLP-based distributed tracing.

**Location:** `src/main/resources/application.yaml`
```yaml
app:
  tracing:
    enabled: false
    sampling-probability: 1.0
management:
  otlp:
    tracing:
      endpoint: http://localhost:4317
```

**Test Environment:** `src/test/resources/application-test.yaml`
```yaml
app:
  logging:
    aspect:
      enabled: false  # AOP logging is disabled in test environment
```

### Security & Actuator
With the addition of `spring-boot-starter-security` and `spring-boot-starter-actuator`, the application has security enabled by default and exposes management endpoints. 

**Note:** Further configuration is required to define specific security rules and to expose additional actuator endpoints (like `/actuator/prometheus`).

### Test Context Isolation
The base application test imports a test-specific configuration (`MetricsConfigurationTest`) to ensure a clean context for unit and integration tests, isolating them from production metric beans.

## Database Configuration Management

### Environment Variables

#### Required Variables
```bash
# PostgreSQL Configuration
export POSTGRES_DB_HOST=localhost
export POSTGRES_DB_PORT=5432
export POSTGRES_DB_NAME=upmatches
export POSTGRES_DB_USER=postgres
export POSTGRES_DB_PASS=password

# Connection Pool Tuning (Optional)
export DB_POOL_SIZE=10
export DB_POOL_MIN_IDLE=2
export DB_IDLE_TIMEOUT=300000
export DB_MAX_LIFETIME=1800000
export DB_CONNECTION_TIMEOUT=30000
export DB_LEAK_DETECTION=60000
```

#### Application Configuration
```bash
export APPLICATION_NAME=upmatches
export SHOW_SQL_FLAG=false
```

### Profile-Based Configuration

The connection pool name is automatically suffixed with active Spring profiles:

```mermaid
graph TD
    A[Spring Profiles] --> B{Pool Name Generation}
    B -->|No Profiles| C["hikari-pool"]
    B -->|With Profiles| D["hikari-pool-<profile1>-<profile2>"]
    
    E[Application Name] --> F{Application Name Generation}
    F -->|No Spring App Name| G["upmatches"]
    F -->|With Spring App Name| H["<app-name>-<profiles>"]
```

### Database URL Patterns

#### PostgreSQL
```
jdbc:postgresql://host:port/database?param1=value1&param2=value2
```

#### H2 (In-Memory)
```
jdbc:h2:mem:databaseName;DB_CLOSE_DELAY=-1
```

#### H2 (File-Based)
```
jdbc:h2:file:/path/to/database
```

#### MySQL
```
jdbc:mysql://host:port/database?useSSL=false&serverTimezone=UTC
```

### Configuration Validation

The system performs the following validations:

1. **URL Presence**: JDBC URL must be configured
2. **Database Type**: URL must match supported database types
3. **Connection Parameters**: Credentials and connection settings validated
4. **Pool Configuration**: Pool size and timeout values validated

### Logging Configuration

Database configuration logs include:
- Pool initialization details
- Connection parameters (with sensitive data masked)
- Database type detection
- Applied optimizations
- Metrics integration status

Example log output:
```
HikariCP configured:
   Pool Name: hikari-pool-dev
   Pool Size: min=2, max=10
   Timeouts: connection=30000ms, idle=300000ms, maxLifetime=1800000ms
   Leak Detection: 60000ms
   Database URL: jdbc:postgresql://***:***@localhost:5432/testdb
   Driver: org.postgresql.Driver
   Application Name: upmatches-dev
```

### Security Considerations

1. **Password Masking**: URLs are masked in logs
2. **Connection Security**: SSL/TLS recommended for production
3. **Credential Management**: Use environment variables or secret management
4. **Network Security**: Restrict database access to application servers

### Troubleshooting

#### Common Issues

1. **Connection Timeouts**
   - Check `DB_CONNECTION_TIMEOUT` value
   - Verify network connectivity
   - Validate database credentials

2. **Pool Exhaustion**
   - Increase `DB_POOL_SIZE`
   - Review connection leak detection
   - Check application connection usage patterns

3. **Database Type Detection Failures**
   - Verify JDBC URL format
   - Check supported database types
   - Ensure driver class is available

#### Diagnostic Commands

```bash
# Check database connectivity
nc -zv ${POSTGRES_DB_HOST} ${POSTGRES_DB_PORT}

# Verify environment variables
printenv | grep -E "(POSTGRES|DB_)"

# Test connection pool
curl http://localhost:8080/actuator/health
```

### Performance Tuning

#### Recommended Settings by Environment

| Environment | Pool Size | Min Idle | Max Lifetime | Notes |
|-------------|-----------|----------|--------------|-------|
| Development | 5-10 | 2 | 30min | Lower overhead |
| Testing | 10-20 | 5 | 30min | Balanced performance |
| Production | 20-50 | 10 | 30min | High availability |
| Staging | 10-30 | 5 | 30min | Mirror production |

#### Monitoring Metrics

Key metrics to monitor:
- `hikaricp.connections.active`: Active connections
- `hikaricp.connections.idle`: Idle connections
- `hikaricp.connections.pending`: Pending connection requests
- `hikaricp.connections.timeout`: Connection timeouts
- `hikaricp.connections.creation`: Connection creation rate