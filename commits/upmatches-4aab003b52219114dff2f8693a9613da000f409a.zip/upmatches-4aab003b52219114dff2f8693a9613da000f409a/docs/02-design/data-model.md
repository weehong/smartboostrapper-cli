# Data Model

This document contains ER Diagrams and Schema explanations.

## ER Diagram
<!-- Add Mermaid ER diagram here -->

## Schema Description
<!-- Describe key entities and relationships -->

## Database Configuration

### Overview
The application now includes a comprehensive database configuration system built on HikariCP connection pooling with support for multiple database types (PostgreSQL, H2, MySQL). The configuration is centralized in a dedicated `DatabaseConfiguration` class that provides optimized settings for each database type.

### Database Support Matrix

```mermaid
graph TD
    A[Database Configuration] --> B[PostgreSQL]
    A --> C[H2]
    A --> D[MySQL]
    
    B --> B1[Connection Pooling]
    B --> B2[Query Optimization]
    B --> B3[Extended Properties]
    
    C --> C1[In-Memory Mode]
    C --> C2[Test Configuration]
    C --> C3[Development]
    
    D --> D1[MySQL Connector]
    D --> D2[Production Ready]
```

### Configuration Properties

#### Core Database Properties
```yaml
spring:
  datasource:
    url: jdbc:postgresql://${POSTGRES_DB_HOST}:${POSTGRES_DB_PORT}/${POSTGRES_DB_NAME}
    username: ${POSTGRES_DB_USER}
    password: ${POSTGRES_DB_PASS}
    driverClassName: # Optional - auto-detected from URL
```

#### HikariCP Pool Configuration
```yaml
spring:
  datasource:
    hikari:
      maximum-pool-size: ${DB_POOL_SIZE:10}
      minimum-idle: ${DB_POOL_MIN_IDLE:2}
      idle-timeout: ${DB_IDLE_TIMEOUT:300000}
      max-lifetime: ${DB_MAX_LIFETIME:1800000}
      connection-timeout: ${DB_CONNECTION_TIMEOUT:30000}
      leak-detection-threshold: ${DB_LEAK_DETECTION:60000}
```

### Database Type Detection

The system automatically detects database type from JDBC URL:

| Database Type | JDBC Prefix | Driver Class |
|---------------|-------------|--------------|
| PostgreSQL | `jdbc:postgresql:` | `org.postgresql.Driver` |
| H2 | `jdbc:h2:` | `org.h2.Driver` |
| MySQL | `jdbc:mysql:` | `com.mysql.cj.jdbc.Driver` |

### Database-Specific Optimizations

#### PostgreSQL Optimizations
```java
hikariConfig.addDataSourceProperty("tcpKeepAlive", "true");
hikariConfig.addDataSourceProperty("ApplicationName", applicationName);
hikariConfig.addDataSourceProperty("assumeMinServerVersion", "12.0");
hikariConfig.addDataSourceProperty("reWriteBatchedInserts", "true");
hikariConfig.addDataSourceProperty("prepareThreshold", "5");
hikariConfig.addDataSourceProperty("preparedStatementCacheQueries", "250");
hikariConfig.addDataSourceProperty("preparedStatementCacheSizeMiB", "5");
hikariConfig.addDataSourceProperty("maintainTimeStats", "false");
```

#### H2 Optimizations
```java
hikariConfig.addDataSourceProperty("DB_CLOSE_DELAY", "-1");
hikariConfig.addDataSourceProperty("DB_CLOSE_ON_EXIT", "FALSE");
hikariConfig.addDataSourceProperty("CACHE_SIZE", "65536");
hikariConfig.addDataSourceProperty("LOCK_TIMEOUT", "10000");
```

### Connection Pool Architecture

```mermaid
graph LR
    A[Application] --> B[HikariCP Pool]
    B --> C[Connection 1]
    B --> D[Connection 2]
    B --> E[Connection N]
    C --> F[(Database)]
    D --> F
    E --> F
    
    G[Metrics Registry] --> B
    H[Configuration Properties] --> B
    I[Environment Variables] --> H
```

### Default Constants

| Constant | Value | Description |
|----------|-------|-------------|
| `DEFAULT_MAXIMUM_POOL_SIZE` | 10 | Maximum connections in pool |
| `DEFAULT_MINIMUM_IDLE` | 10 | Minimum idle connections |
| `DEFAULT_CONNECTION_TIMEOUT` | 30000ms | Connection timeout |
| `DEFAULT_IDLE_TIMEOUT` | 600000ms | Idle connection timeout |
| `DEFAULT_MAX_LIFETIME` | 1800000ms | Maximum connection lifetime |
| `DEFAULT_POOL_NAME` | "hikari-pool" | Base pool name |
| `DEFAULT_APPLICATION_NAME` | "upmatches" | Default app name |

### Monitoring and Metrics

The configuration integrates with Micrometer for connection pool metrics:
- Connection pool size metrics
- Connection usage statistics
- Connection timeout tracking
- Leak detection metrics

### Error Handling

The configuration includes comprehensive error handling:
- Validates JDBC URL presence
- Validates database type support
- Provides meaningful error messages
- Graceful fallback to defaults

### Testing Strategy

The system includes extensive unit tests covering:
- Database type detection
- Connection pool configuration
- Error scenarios
- Property resolution
- Database-specific optimizations