# Development Environment Setup

This project uses a standard Java/Spring Boot development environment with Maven as the build tool.

### Prerequisites

- **Java 21** or higher
- **Maven** (automatically managed via Maven Wrapper)
- **GitHub Packages Credentials**: Required for downloading custom Checkstyle rules.
  - `GITHUB_USERNAME`
  - `GITHUB_TOKEN`

### Project Structure
... (existing structure)

### Build System

The project uses **Maven Wrapper** (version 3.3.4) which ensures consistent builds across different environments.

#### Repository Configuration

To download dependencies from GitHub Packages, the following repository is configured in `pom.xml`:

```xml
<repository>
    <id>github</id>
    <name>GitHub Packages</name>
    <url>https://maven.pkg.github.com/weehong/checkstyle-rule</url>
</repository>
```

#### Build Commands

```bash
# Build and compile the project
./mvnw clean compile

# Run tests with coverage checks
./mvnw verify

# Run code style validation
./mvnw checkstyle:check

# Run the application locally
./mvnw spring-boot:run
```

### IDE Configuration

The project includes IDE-specific ignore patterns in `.gitignore` for:
- **IntelliJ IDEA** (`.idea/`, `*.iml`)
- **Eclipse/STS** (`.project`, `.classpath`, `.settings/`)
- **VS Code** (`.vscode/`)
- **NetBeans` (`nbproject/`, `build/`)

### Dependencies

Core dependencies defined in `pom.xml`:
- **Spring Boot Starter** (4.0.1)
- **Spring Boot Starter Test** (test scope)
- **Java 21** compatibility

### Git Configuration

The `.gitattributes` file ensures consistent line endings:
- Unix line endings (`LF`) for shell scripts (`mvnw`)
- Windows line endings (`CRLF`) for batch files (`*.cmd`)

### Getting Started

1. Clone the repository
2. Ensure Java 21 is installed
3. Run `./mvnw spring-boot:run` to start the application
4. Access the application at `http://localhost:8080`

The Maven wrapper will automatically download the required Maven version (3.9.12) on first run if not already available in the local cache.
