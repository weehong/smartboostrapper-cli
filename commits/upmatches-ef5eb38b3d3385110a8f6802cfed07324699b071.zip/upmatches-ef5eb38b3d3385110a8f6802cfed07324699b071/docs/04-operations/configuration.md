# Application Configuration

The system uses Spring Boot's externalized configuration and supports multiple environments via YAML profiles and environment variables.

**Main Configuration File:** `src/main/resources/application.yaml`
```yaml
server:
  port: ${SERVER_PORT:8080}
spring:
  application:
    name: ${APPLICATION_NAME:upmatches}
```

**Test Configuration:** `src/test/resources/application-test.yaml`
```yaml
server:
  port: ${SERVER_PORT:0}  # Random port for tests
spring:
  application:
    name: ${APPLICATION_NAME:upmatches}
```

## Environment Variables

| Variable | Default | Purpose |
|----------|---------|---------|
| `SERVER_PORT` | 8080 | Application server port |
| `APPLICATION_NAME` | upmatches | Spring application name |
| `GITHUB_USERNAME` | - | GitHub Packages authentication |
| `GITHUB_TOKEN` | - | GitHub Packages token |
| `SONAR_TOKEN` | - | SonarCloud authentication |
| `DOCKERHUB_USERNAME`| - | Docker Hub username |
| `DOCKERHUB_PASSWORD`| - | Docker Hub password |

## Profiles

- **default**: Standard configuration for development.
- **test**: Activated during test execution using `@ActiveProfiles("test")`.