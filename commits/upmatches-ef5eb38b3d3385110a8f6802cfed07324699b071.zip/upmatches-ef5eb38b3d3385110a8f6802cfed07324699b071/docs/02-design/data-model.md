# Data Model

This document contains ER Diagrams and Schema explanations.

## ER Diagram
<!-- Add Mermaid ER diagram here -->

## Schema Description
<!-- Describe key entities and relationships -->
