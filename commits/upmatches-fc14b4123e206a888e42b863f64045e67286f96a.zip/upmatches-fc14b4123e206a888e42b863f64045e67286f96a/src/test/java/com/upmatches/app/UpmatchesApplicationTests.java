package com.upmatches.app;

import com.upmatches.app.shared.metrics.configurations.MetricsConfigurationTest;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("test")
@Import(MetricsConfigurationTest.class)
class UpmatchesApplicationTests {

    @Test
    void contextLoads() {
    }

}
