# API Error Response Specification

## RFC 7807 Problem Details Implementation

### Base Structure
All error responses follow the RFC 7807 Problem Details format with custom extensions:

```json
{
  "type": "string",
  "title": "string",
  "status": "number",
  "detail": "string",
  "instance": "string",
  "errorCode": "string",
  "errors": [
    {
      "field": "string",
      "message": "string"
    }
  ],
  "customProperties": {
    "key": "value"
  }
}
```

### Standard Problem Types

#### 400 Bad Request - Validation Error
```json
{
  "type": "about:blank",
  "title": "Bad Request",
  "status": 400,
  "detail": "Validation failed",
  "instance": "/api/v1/users",
  "errors": [
    {
      "field": "email",
      "message": "must be a well-formed email address"
    },
    {
      "field": "password",
      "message": "must be at least 8 characters long"
    }
  ]
}
```

#### 404 Not Found - Resource Not Found
```json
{
  "type": "about:blank",
  "title": "Not Found",
  "status": 404,
  "detail": "User with id 123 not found",
  "instance": "/api/v1/users/123",
  "errorCode": "RESOURCE_NOT_FOUND"
}
```

#### 500 Internal Server Error - External Service Failure
```json
{
  "type": "about:blank",
  "title": "Internal Server Error",
  "status": 500,
  "detail": "External service error during retrieve: Service Unavailable",
  "instance": "/api/v1/payments",
  "errorCode": "EXTERNAL_SERVICE_ERROR",
  "httpStatusCode": 503,
  "responseBody": "{\"error\":\"Service maintenance\"}\n\n--- RESPONSE TRUNCATED (exceeded 10KB limit) ---",
  "causeType": "ResourceAccessException"
}
```

#### 409 Conflict - Database Constraint Violation
```json
{
  "type": "about:blank",
  "title": "Conflict",
  "status": 409,
  "detail": "Data integrity violation - duplicate entry or constraint failure",
  "instance": "/api/v1/users",
  "errorCode": "DATA_INTEGRITY_VIOLATION"
}
```

## HTTP Status Code Mapping

### Client Errors (4xx)
| Status Code | Exception |
|-------------|-----------|
| 400 | `MethodArgumentNotValidException` |
| 400 | `ConstraintViolationException` |
| 404 | `ResourceNotFoundException` |
| 409 | `DataIntegrityViolationException` |
| 409 | `EntityExistsException` |

### Server Errors (5xx)
| Status Code | Exception |
|-------------|-----------|
| 500 | `ExternalServiceException` |
| 500 | `JpaSystemException` |
| 503 | `ResourceAccessException` |
| 500 | Generic `RuntimeException` |

### Database Locking Errors
| Status Code | Exception |
|-------------|-----------|
| 409 | `OptimisticLockingFailureException` |
| 423 | `CannotAcquireLockException` |
| 408 | `DeadlockLoserDataAccessException` |
