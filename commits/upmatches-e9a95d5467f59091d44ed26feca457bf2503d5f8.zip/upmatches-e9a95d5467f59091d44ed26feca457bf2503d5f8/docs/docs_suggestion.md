### FILE: 02-design/error-handling.md
```markdown
# Error Handling Design

## Overview
The error handling system provides a consistent, structured approach to exception management across the application. It follows RESTful best practices using RFC 7807 Problem Details for HTTP APIs.

## Architecture Components

### Exception Hierarchy
```mermaid
classDiagram
    class BaseException {
        <<abstract>>
        -HttpStatus httpStatus
        -String errorCode
        -Map~String,Object~ customProperties
        +toProblemDetail(String instance) ProblemDetail
        +addProperty(String key, Object value) BaseException
    }
    
    class ResourceNotFoundException {
        +ResourceNotFoundException(String message)
    }
    
    class ExternalServiceException {
        +ExternalServiceException(String message, Throwable cause, Integer statusCode, String responseBody)
    }
    
    class InvalidFileException {
        +InvalidFileException(String message, Throwable cause)
    }
    
    BaseException <|-- ResourceNotFoundException
    BaseException <|-- ExternalServiceException
    RuntimeException <|-- InvalidFileException
    
    note for BaseException "Implements RFC 7807 Problem Details"
```

### Global Exception Handler
The `GlobalExceptionHandler` centralizes exception processing with the following capabilities:

1. **BaseException Handling**: Converts custom exceptions to RFC 7807 Problem Details
2. **Validation Errors**: Handles `@Valid` annotation failures and constraint violations
3. **Structured Error Responses**: Provides consistent error format across all endpoints

### Response Format
All errors follow this structure:
```json
{
  "type": "about:blank",
  "title": "Bad Request",
  "status": 400,
  "detail": "Validation failed",
  "instance": "/api/v1/users",
  "errorCode": "VALIDATION_ERROR",
  "errors": [
    {
      "field": "email",
      "message": "must be a well-formed email address"
    }
  ]
}
```

## Exception Types

### ResourceNotFoundException
- **HTTP Status**: 404 Not Found
- **Error Code**: `RESOURCE_NOT_FOUND`
- **Use Case**: Requested resource doesn't exist

### ExternalServiceException
- **HTTP Status**: Mapped from external service response (or 500)
- **Error Code**: `EXTERNAL_SERVICE_ERROR`
- **Properties**: Includes HTTP status code and response body from external service
- **Use Case**: External API calls fail

### InvalidFileException
- **HTTP Status**: 400 Bad Request
- **Use Case**: File upload validation failures

## Validation Error Handling

### MethodArgumentNotValidException
Handles Spring `@Valid` annotation failures with detailed field-level errors.

### ConstraintViolationException
Handles Jakarta Bean Validation constraint violations with property path extraction.

## Configuration

### Dependencies
```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-validation</artifactId>
</dependency>
```

### Logging
- BaseException: ERROR level with stack trace
- Validation errors: WARN level without stack trace
- Request tracing via MDC (requestId)

## Usage Examples

### Throwing Custom Exceptions
```java
throw new ResourceNotFoundException("User with id " + userId + " not found");
```

### Adding Custom Properties
```java
throw new ExternalServiceException("Payment service failed", ex, 503, responseBody)
    .addProperty("service", "payment-gateway")
    .addProperty("retryAfter", "30s");
```

### Validation Annotations
```java
@PostMapping("/users")
public ResponseEntity<User> createUser(@Valid @RequestBody UserRequest request) {
    // Automatically validated by GlobalExceptionHandler
}
```

## Best Practices

1. **Use Specific Exception Types**: Choose the most appropriate exception type
2. **Include Context**: Add relevant properties for debugging
3. **Log Appropriately**: Use correct log levels (ERROR for system failures, WARN for client errors)
4. **Request Tracing**: Ensure MDC is populated for correlation
5. **Security**: Don't expose sensitive information in error responses
```

### FILE: 02-design/service-operation-executor.md
```markdown
# Service Operation Executor Pattern

## Overview
The `ServiceOperationExecutor` provides a centralized, consistent approach to executing service operations with comprehensive error handling, logging, and monitoring capabilities.

## Design Pattern

### Unified Execution Flow
```mermaid
flowchart TD
    A[Start Operation] --> B[Generate/Get Trace ID]
    B --> C[Log Operation Start]
    C --> D[Execute Operation]
    D --> E{Success?}
    E -->|Yes| F[Log Success]
    F --> G[Return Result]
    
    E -->|No| H{Exception Type?}
    H -->|Database| I[Handle Database Exception]
    H -->|External Service| J[Handle RestClient Exception]
    H -->|File| K[Handle File Exception]
    H -->|Resource Not Found| L[Handle Resource Not Found]
    H -->|Programmer Error| M[Bubble Up]
    H -->|Other Runtime| N[Wrap in Generic Exception]
    
    I --> O[Map to Business Exception]
    J --> P[Create ExternalServiceException]
    K --> Q[Wrap in Factory Exception]
    L --> R[Re-throw As-Is]
    M --> R
    N --> Q
    
    O --> S[Log Error]
    P --> S
    Q --> S
    R --> S
    
    S --> T[Throw Mapped Exception]
```

## Core Components

### OperationStatus Enum
Defines the type of operation being performed:
- `RETRIEVE`: Read operations
- `SAVE`: Create operations
- `UPDATE`: Update operations
- `DELETE`: Delete operations
- `OTHER`: Miscellaneous operations

### ExceptionFactory Interface
```java
@FunctionalInterface
public interface ExceptionFactory {
    RuntimeException create(String message, Throwable cause);
}
```
Allows custom exception creation strategies.

### ServiceOperationExecutorConstant
Configuration constants:
- `MAX_RESPONSE_BODY_SIZE`: 10,000 bytes (10KB)
- `TRUNCATION_INDICATOR`: "\n\n--- RESPONSE TRUNCATED (exceeded 10KB limit) ---"
- `MDC_REQUEST_ID_KEY`: "requestId"

## Execution Methods

### execute() - For Operations Returning Values
```java
public static <T> T execute(
    Supplier<T> operation,
    OperationStatus operationType,
    ExceptionFactory exceptionFactory
)
```

### executeVoid() - For Void Operations
```java
public static void executeVoid(
    Runnable operation,
    OperationStatus operationType,
    ExceptionFactory exceptionFactory
)
```

## Exception Mapping Strategy

### Database Exceptions
| Exception Type | Business Meaning | Response |
|----------------|------------------|----------|
| `EntityNotFoundException` | Resource doesn't exist | Custom message based on operation type |
| `EntityExistsException` | Duplicate resource | "Entity already exists" |
| `DataIntegrityViolationException` | Constraint violation | Operation-specific constraint message |
| `OptimisticLockingFailureException` | Concurrent modification | "Concurrent modification detected - please retry" |
| `DeadlockLoserDataAccessException` | Database deadlock | "Database deadlock detected - please retry" |
| `CannotAcquireLockException` | Resource locked | "Cannot acquire database lock - resource may be in use" |

### External Service Exceptions
| Exception Type | Business Meaning | Response |
|----------------|------------------|----------|
| `HttpStatusCodeException` | External service error | Includes status code and truncated response body |
| `ResourceAccessException` | Service unavailable | "External service unavailable" |

### Programmer Errors (Bubbled Up)
- `NullPointerException`
- `IllegalStateException`
- `UnsupportedOperationException`
- `ClassCastException`
- `IndexOutOfBoundsException`
- `ArithmeticException`
- `NumberFormatException`

## Logging Strategy

### Structured Logging
```json
{
  "timestamp": "2024-01-15T10:30:00Z",
  "level": "ERROR",
  "requestId": "550e8400-e29b-41d4-a716-446655440000",
  "operation": "SAVE",
  "message": "Database exception occurred",
  "exceptionType": "DataIntegrityViolationException"
}
```

### Log Levels
- **DEBUG**: Operation start/end, trace ID management
- **WARN**: Validation failures, expected business errors
- **ERROR**: System failures, unexpected exceptions

## Configuration

### Trace ID Management
```java
private static String getOrCreateTraceId() {
    String existingTraceId = MDC.get(MDC_REQUEST_ID_KEY);
    
    if (existingTraceId != null && !existingTraceId.isBlank()) {
        return existingTraceId;
    }
    
    String newTraceId = randomUUID().toString();
    MDC.put(MDC_REQUEST_ID_KEY, newTraceId);
    return newTraceId;
}
```

### Response Body Truncation
Large external service responses are truncated to 10KB to prevent memory issues and log flooding.

## Usage Examples

### Basic Usage
```java
public User findUserById(Long userId) {
    return ServiceOperationExecutor.execute(
        () -> userRepository.findById(userId)
            .orElseThrow(() -> new ResourceNotFoundException("User not found")),
        OperationStatus.RETRIEVE,
        (message, cause) -> new ServiceException(message, cause)
    );
}
```

### Void Operation
```java
public void deleteUser(Long userId) {
    ServiceOperationExecutor.executeVoid(
        () -> {
            User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
            userRepository.delete(user);
        },
        OperationStatus.DELETE,
        (message, cause) -> new ServiceException(message, cause)
    );
}
```

### Custom Exception Factory
```java
ExceptionFactory factory = (message, cause) -> 
    new BusinessException("USER_OPERATION_FAILED", message, cause);

ServiceOperationExecutor.execute(
    () -> userService.complexOperation(),
    OperationStatus.UPDATE,
    factory
);
```

## Best Practices

1. **Always Provide Operation Type**: Helps with logging and exception mapping
2. **Use Appropriate Exception Factory**: Create meaningful business exceptions
3. **Handle Programmer Errors Separately**: Let NPEs and other bugs bubble up
4. **Include Trace IDs**: Ensure correlation across distributed systems
5. **Monitor Database Exception Rates**: Use metrics to track persistence layer health
6. **Test Exception Paths**: Ensure all exception types are properly mapped
```

### FILE: 04-operations/configuration.md
```markdown
# Database Connection Pool Configuration

## Overview
The application uses HikariCP as the connection pool implementation with optimized settings for production workloads.

## Configuration Changes

### Updated Settings
```yaml
spring:
  datasource:
    hikari:
      # Pool size: recommended formula is (core_count × 2) + effective_spindle_count
      # For most applications, 10 is a reasonable default. Adjust DB_POOL_SIZE as needed.
      maximum-pool-size: ${DB_POOL_SIZE:10}
      # Set minimum-idle equal to maximum-pool-size to avoid connection churn
      minimum-idle: ${DB_POOL_SIZE:10}
      idle-timeout: ${DB_IDLE_TIMEOUT:300000}
      max-lifetime: ${DB_MAX_LIFETIME:1800000}
      connection-timeout: ${DB_CONNECTION_TIMEOUT:30000}
```

## Key Changes Explained

### Minimum Idle Connections
**Before**: `minimum-idle: ${DB_POOL_MIN_IDLE:2}`  
**After**: `minimum-idle: ${DB_POOL_SIZE:10}`

#### Rationale:
1. **Connection Churn Reduction**: By keeping `minimum-idle` equal to `maximum-pool-size`, the pool maintains all connections, eliminating the overhead of creating/destroying connections during normal operation.
2. **Performance**: Warm connections are immediately available, reducing latency for database operations.
3. **Resource Efficiency**: Modern databases handle persistent connections efficiently, making this approach preferable for most applications.

### Connection Pool Sizing Formula
The recommended formula for connection pool sizing is:
```
(core_count × 2) + effective_spindle_count
```

Where:
- `core_count`: Number of CPU cores
- `effective_spindle_count`: For SSDs = 0, for HDDs = number of spindles

For a typical 4-core server with SSD storage:
```
(4 × 2) + 0 = 8 connections
```

The default of 10 provides a safe buffer for most applications.

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `DB_POOL_SIZE` | 10 | Maximum and minimum number of connections in the pool |
| `DB_IDLE_TIMEOUT` | 300000ms (5 min) | Maximum time a connection can sit idle |
| `DB_MAX_LIFETIME` | 1800000ms (30 min) | Maximum lifetime of a connection |
| `DB_CONNECTION_TIMEOUT` | 30000ms (30 sec) | Maximum time to wait for a connection |

## Monitoring Recommendations

### Key Metrics to Monitor
1. **Active Connections**: Should stay below `maximum-pool-size`
2. **Idle Connections**: Should be close to `minimum-idle` during steady state
3. **Connection Timeouts**: Indicates pool is too small
4. **Connection Creation Rate**: High rates indicate connection churn

### Health Check Configuration
Consider adding connection validation:
```yaml
spring:
  datasource:
    hikari:
      connection-test-query: "SELECT 1"
      validation-timeout: 5000
```

## Troubleshooting

### Common Issues

#### Connection Leaks
Symptoms: Pool reaches `maximum-pool-size` and stays there.

Solutions:
1. Ensure all connections are properly closed in `finally` blocks or using try-with-resources
2. Monitor for long-running transactions
3. Check for missing `@Transactional` annotations

#### Timeout Errors
Symptoms: `ConnectionTimeoutException` in logs.

Solutions:
1. Increase `DB_POOL_SIZE` if system load has increased
2. Check database server performance
3. Verify network connectivity between application and database

#### High Connection Churn
Symptoms: Frequent connection creation/destruction.

Solutions:
1. Ensure `minimum-idle` is appropriately sized (already addressed in this change)
2. Check `idle-timeout` isn't too low
3. Monitor for connection validation failures

## Performance Tuning

### Production Recommendations
1. **Start with Defaults**: The updated defaults work well for most applications
2. **Monitor Before Tuning**: Collect metrics for 24-48 hours before making changes
3. **Adjust Based on Load**: Increase `DB_POOL_SIZE` during peak periods if needed
4. **Consider Read/Write Splitting**: For heavy read workloads, consider separate pools

### Testing Configuration
```yaml
# Test profile - smaller pool
spring:
  datasource:
    hikari:
      maximum-pool-size: 5
      minimum-idle: 2
```

## Migration Notes
Applications upgrading to this configuration should:
1. Monitor connection pool metrics closely after deployment
2. Ensure database server has sufficient connections available (check `max_connections` setting)
3. Update any existing monitoring dashboards to track the new metrics
```

### FILE: 03-technical/api-error-responses.md
```markdown
# API Error Response Specification

## RFC 7807 Problem Details Implementation

### Base Structure
All error responses follow the RFC 7807 Problem Details format with custom extensions:

```json
{
  "type": "string",
  "title": "string",
  "status": "number",
  "detail": "string",
  "instance": "string",
  "errorCode": "string",
  "errors": [
    {
      "field": "string",
      "message": "string"
    }
  ],
  "customProperties": {
    "key": "value"
  }
}
```

### Standard Problem Types

#### 400 Bad Request - Validation Error
```json
{
  "type": "about:blank",
  "title": "Bad Request",
  "status": 400,
  "detail": "Validation failed",
  "instance": "/api/v1/users",
  "errors": [
    {
      "field": "email",
      "message": "must be a well-formed email address"
    },
    {
      "field": "password",
      "message": "must be at least 8 characters long"
    }
  ]
}
```

#### 404 Not Found - Resource Not Found
```json
{
  "type": "about:blank",
  "title": "Not Found",
  "status": 404,
  "detail": "User with id 123 not found",
  "instance": "/api/v1/users/123",
  "errorCode": "RESOURCE_NOT_FOUND"
}
```

#### 500 Internal Server Error - External Service Failure
```json
{
  "type": "about:blank",
  "title": "Internal Server Error",
  "status": 500,
  "detail": "External service error during retrieve: Service Unavailable",
  "instance": "/api/v1/payments",
  "errorCode": "EXTERNAL_SERVICE_ERROR",
  "httpStatusCode": 503,
  "responseBody": "{\"error\":\"Service maintenance\"}\n\n--- RESPONSE TRUNCATED (exceeded 10KB limit) ---",
  "causeType": "ResourceAccessException"
}
```

#### 409 Conflict - Database Constraint Violation
```json
{
  "type": "about:blank",
  "title": "Conflict",
  "status": 409,
  "detail": "Data integrity violation - duplicate entry or constraint failure",
  "instance": "/api/v1/users",
  "errorCode": "DATA_INTEGRITY_VIOLATION"
}
```

## HTTP Status Code Mapping

### Client Errors (4xx)
| Status Code | Exception | Trigger |
|-------------|-----------|---------|
| 400 | `MethodArgumentNotValidException` | Request body validation fails |
| 400 | `ConstraintViolationException` | Bean validation fails |
| 404 | `ResourceNotFoundException` | Requested resource doesn't exist |
| 409 | `DataIntegrityViolationException` | Database constraint violation |
| 409 | `EntityExistsException` | Attempt to create duplicate resource |

### Server Errors (5xx)
| Status Code | Exception | Trigger |
|-------------|-----------|---------|
| 500 | `ExternalServiceException` | External API call fails |
| 500 | `JpaSystemException` | JPA persistence error |
| 503 | `ResourceAccessException` | External service unavailable |
| 500 | Generic `RuntimeException` | Unhandled system error |

### Database Locking Errors
| Status Code | Exception | Business Meaning |
|-------------|-----------|------------------|
| 409 | `OptimisticLockingFailureException` | Concurrent modification |
| 423