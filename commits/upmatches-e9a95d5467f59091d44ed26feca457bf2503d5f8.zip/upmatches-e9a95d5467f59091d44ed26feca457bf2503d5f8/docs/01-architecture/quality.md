# Quality Attributes (NFRs)

This document details the Non-Functional Requirements such as Scalability and Security.

## Scalability
<!-- Describe scalability requirements and strategies -->

## Security
<!-- Describe security requirements -->
