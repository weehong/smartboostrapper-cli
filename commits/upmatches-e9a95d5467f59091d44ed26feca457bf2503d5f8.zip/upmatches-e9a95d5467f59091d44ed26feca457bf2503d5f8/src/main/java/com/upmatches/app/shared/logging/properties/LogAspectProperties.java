package com.upmatches.app.shared.logging.properties;

import com.upmatches.app.shared.logging.constants.AspectConstant;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "app.logging.aspect")
public record LogAspectProperties(
    boolean enabled,
    long slowExecutionThresholdMs
) {
    public LogAspectProperties {
        if (slowExecutionThresholdMs <= 0) {
            slowExecutionThresholdMs = AspectConstant.SLOW_EXECUTION_THRESHOLD_MS;
        }
    }
}
