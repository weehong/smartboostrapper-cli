package com.upmatches.app.shared.core.exceptions.types;

public class InvalidFileException extends RuntimeException {

    public InvalidFileException(String message, Throwable cause) {
        super(message, cause);
    }

}
