package com.upmatches.app.shared.core.enums;

public enum OperationStatus {
    RETRIEVE,
    SAVE,
    UPDATE,
    DELETE,
    OTHER
}
