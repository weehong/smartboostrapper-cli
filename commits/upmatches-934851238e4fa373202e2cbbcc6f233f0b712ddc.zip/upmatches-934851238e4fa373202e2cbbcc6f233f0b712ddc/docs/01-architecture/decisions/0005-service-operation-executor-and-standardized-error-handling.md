# ADR-005: Service Operation Executor and Standardized Error Handling

**Date:** 2025-12-29
**Status:** Accepted

## Context
The application needs a consistent way to handle service-layer operations, cross-cutting concerns (logging, tracing), and a unified error response format for the API.

1. **Inconsistent Error Responses**: Different parts of the application might return different error structures.
2. **Boilerplate Code**: Repetitive try-catch blocks for logging and exception wrapping in service classes.
3. **Observability**: Difficulty in correlating logs across service calls without a unified tracing mechanism.
4. **API Standards**: Need to follow industry standards like RFC 7807 for HTTP problem details.

## Decision
Implement the `ServiceOperationExecutor` pattern and a centralized error handling strategy using Spring Boot's `@RestControllerAdvice`.

### Service Operation Executor
A centralized component to wrap service method executions:
```mermaid
flowchart TD
    A[Service Call] --> B[Executor]
    B --> C[Trace ID Setup]
    C --> D[Log Start]
    D --> E[Execute Operation]
    E --> F{Success?}
    F -->|Yes| G[Log Success]
    G --> H[Return Result]
    F -->|No| I[Exception Mapping]
    I --> J[Log Error]
    J --> K[Throw Business Exception]
```

### Standardized Error Responses
Adopt RFC 7807 (Problem Details for HTTP APIs) as the standard response format.

## Components

1. **ServiceOperationExecutor**: Utility to execute suppliers/runnables with logging and exception mapping.
2. **GlobalExceptionHandler**: `@RestControllerAdvice` to convert exceptions to `ProblemDetail`.
3. **BaseException**: Abstract base for all business exceptions, implementing RFC 7807 requirements.
4. **ExceptionFactory**: Functional interface for customized exception creation.

## Rationale

### Why RFC 7807?
- **Standardization**: Machine-readable format for errors.
- **Interoperability**: Clients can handle errors in a predictable way.
- **Richness**: Allows adding custom properties without breaking standard fields.

### Why ServiceOperationExecutor?
- **DRY Principle**: Centralizes logging and exception wrapping.
- **Consistency**: Ensures all service operations follow the same lifecycle (tracing, logging, error handling).
- **Maintainability**: Changes to the execution flow (e.g., adding metrics) can be done in one place.

## Consequences

### Positive
- **Improved API UX**: Consistent and informative error messages.
- **Enhanced Observability**: Automatic trace ID propagation and structured logging.
- **Reduced Code Noise**: Service methods focus on business logic rather than error handling boilerplate.
- **Better Error Mapping**: Centralized mapping of technical exceptions (e.g., JPA, RestClient) to business-meaningful ones.

### Negative
- **Abstraction Overhead**: Slight performance impact of lambda execution (negligible).
- **Learning Curve**: Developers need to adapt to the executor pattern instead of standard try-catch.
