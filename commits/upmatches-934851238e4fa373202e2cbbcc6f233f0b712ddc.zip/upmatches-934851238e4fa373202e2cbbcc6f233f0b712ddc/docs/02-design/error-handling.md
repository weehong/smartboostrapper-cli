# Error Handling Design

## Overview
The error handling system provides a consistent, structured approach to exception management across the application. It follows RESTful best practices using RFC 7807 Problem Details for HTTP APIs.

## Architecture Components

### Exception Hierarchy
```mermaid
classDiagram
    class BaseException {
        <<abstract>>
        -HttpStatus httpStatus
        -String errorCode
        -Map~String,Object~ customProperties
        +toProblemDetail(String instance) ProblemDetail
        +addProperty(String key, Object value) BaseException
    }
    
    class ResourceNotFoundException {
        +ResourceNotFoundException(String message)
    }
    
    class ExternalServiceException {
        +ExternalServiceException(String message, Throwable cause, Integer statusCode, String responseBody)
    }
    
    class InvalidFileException {
        +InvalidFileException(String message, Throwable cause)
    }
    
    BaseException <|-- ResourceNotFoundException
    BaseException <|-- ExternalServiceException
    RuntimeException <|-- InvalidFileException
    
    note for BaseException "Implements RFC 7807 Problem Details"
```

### Global Exception Handler
The `GlobalExceptionHandler` centralizes exception processing with the following capabilities:

1. **BaseException Handling**: Converts custom exceptions to RFC 7807 Problem Details
2. **Validation Errors**: Handles `@Valid` annotation failures and constraint violations
3. **Structured Error Responses**: Provides consistent error format across all endpoints

### Response Format
All errors follow this structure:
```json
{
  "type": "about:blank",
  "title": "Bad Request",
  "status": 400,
  "detail": "Validation failed",
  "instance": "/api/v1/users",
  "errorCode": "VALIDATION_ERROR",
  "errors": [
    {
      "field": "email",
      "message": "must be a well-formed email address"
    }
  ]
}
```

## Exception Types

### ResourceNotFoundException
- **HTTP Status**: 404 Not Found
- **Error Code**: `RESOURCE_NOT_FOUND`
- **Use Case**: Requested resource doesn't exist

### ExternalServiceException
- **HTTP Status**: Mapped from external service response (or 500)
- **Error Code**: `EXTERNAL_SERVICE_ERROR`
- **Properties**: Includes HTTP status code and response body from external service
- **Use Case**: External API calls fail

### InvalidFileException
- **HTTP Status**: 400 Bad Request
- **Use Case**: File upload validation failures

## Validation Error Handling

### MethodArgumentNotValidException
Handles Spring `@Valid` annotation failures with detailed field-level errors.

### ConstraintViolationException
Handles Jakarta Bean Validation constraint violations with property path extraction.

## Configuration

### Dependencies
```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-validation</artifactId>
</dependency>
```

### Logging
- BaseException: ERROR level with stack trace
- Validation errors: WARN level without stack trace
- Request tracing via MDC (requestId)

## Usage Examples

### Throwing Custom Exceptions
```java
throw new ResourceNotFoundException("User with id " + userId + " not found");
```

### Adding Custom Properties
```java
throw new ExternalServiceException("Payment service failed", ex, 503, responseBody)
    .addProperty("service", "payment-gateway")
    .addProperty("retryAfter", "30s");
```

### Validation Annotations
```java
@PostMapping("/users")
public ResponseEntity<User> createUser(@Valid @RequestBody UserRequest request) {
    // Automatically validated by GlobalExceptionHandler
}
```

## Best Practices

1. **Use Specific Exception Types**: Choose the most appropriate exception type
2. **Include Context**: Add relevant properties for debugging
3. **Log Appropriately**: Use correct log levels (ERROR for system failures, WARN for client errors)
4. **Request Tracing**: Ensure MDC is populated for correlation
5. **Security**: Don't expose sensitive information in error responses
