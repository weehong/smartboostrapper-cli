# Data Model

This document contains ER Diagrams and Schema explanations.

## ER Diagram
<!-- Add Mermaid ER diagram here -->

## Schema Description
<!-- Describe key entities and relationships -->

## Database Configuration

### Overview
The application now includes a comprehensive database configuration system built on HikariCP connection pooling with support for multiple database types (PostgreSQL, H2, MySQL). The configuration is centralized in a dedicated `DatabaseConfiguration` class that provides optimized settings for each database type.

### Database Support Matrix

```mermaid
graph TD
    A[Database Configuration] --> B[PostgreSQL]
    A --> C[H2]
    A --> D[MySQL]
    
    B --> B1[Connection Pooling]
    B --> B2[Query Optimization]
    B --> B3[Extended Properties]
    
    C --> C1[In-Memory Mode]
    C --> C2[Test Configuration]
    C --> C3[Development]
    
    D --> D1[MySQL Connector]
    D --> D2[Production Ready]
```

### Configuration Properties

#### Core Database Properties
```yaml
spring:
  datasource:
    url: jdbc:postgresql://${POSTGRES_DB_HOST}:${POSTGRES_DB_PORT}/${POSTGRES_DB_NAME}
    username: ${POSTGRES_DB_USER}
    password: ${POSTGRES_DB_PASS}
    driverClassName: # Optional - auto-detected from URL
```

#### HikariCP Pool Configuration
```yaml
spring:
  datasource:
    hikari:
      maximum-pool-size: ${DB_POOL_SIZE:10}
      minimum-idle: ${DB_POOL_MIN_IDLE:2}
      idle-timeout: ${DB_IDLE_TIMEOUT:300000}
      max-lifetime: ${DB_MAX_LIFETIME:1800000}
      connection-timeout: ${DB_CONNECTION_TIMEOUT:30000}
      leak-detection-threshold: ${DB_LEAK_DETECTION:60000}
```

### Database Type Detection

The system automatically detects database type from JDBC URL:

| Database Type | JDBC Prefix | Driver Class |
|---------------|-------------|--------------|
| PostgreSQL | `jdbc:postgresql:` | `org.postgresql.Driver` |
| H2 | `jdbc:h2:` | `org.h2.Driver` |
| MySQL | `jdbc:mysql:` | `com.mysql.cj.jdbc.Driver` |

### Database-Specific Optimizations

#### PostgreSQL Optimizations
```java
hikariConfig.addDataSourceProperty("tcpKeepAlive", "true");
hikariConfig.addDataSourceProperty("ApplicationName", applicationName);
hikariConfig.addDataSourceProperty("assumeMinServerVersion", "12.0");
hikariConfig.addDataSourceProperty("reWriteBatchedInserts", "true");
hikariConfig.addDataSourceProperty("prepareThreshold", "5");
hikariConfig.addDataSourceProperty("preparedStatementCacheQueries", "250");
hikariConfig.addDataSourceProperty("preparedStatementCacheSizeMiB", "5");
hikariConfig.addDataSourceProperty("maintainTimeStats", "false");
```

#### H2 Optimizations
```java
hikariConfig.addDataSourceProperty("DB_CLOSE_DELAY", "-1");
hikariConfig.addDataSourceProperty("DB_CLOSE_ON_EXIT", "FALSE");
hikariConfig.addDataSourceProperty("CACHE_SIZE", "65536");
hikariConfig.addDataSourceProperty("LOCK_TIMEOUT", "10000");
```

### Connection Pool Architecture

```mermaid
graph LR
    A[Application] --> B[HikariCP Pool]
    B --> C[Connection 1]
    B --> D[Connection 2]
    B --> E[Connection N]
    C --> F[(Database)]
    D --> F
    E --> F
    
    G[Metrics Registry] --> B
    H[Configuration Properties] --> B
    I[Environment Variables] --> H
```

### Default Constants

| Constant | Value | Description |
|----------|-------|-------------|
| `DEFAULT_MAXIMUM_POOL_SIZE` | 10 | Maximum connections in pool |
| `DEFAULT_MINIMUM_IDLE` | 10 | Minimum idle connections |
| `DEFAULT_CONNECTION_TIMEOUT` | 30000ms | Connection timeout |
| `DEFAULT_IDLE_TIMEOUT` | 600000ms | Idle connection timeout |
| `DEFAULT_MAX_LIFETIME` | 1800000ms | Maximum connection lifetime |
| `DEFAULT_POOL_NAME` | "hikari-pool" | Base pool name |
| `DEFAULT_APPLICATION_NAME` | "upmatches" | Default app name |

### Monitoring and Metrics

The configuration integrates with Micrometer for connection pool metrics:
- Connection pool size metrics
- Connection usage statistics
- Connection timeout tracking
- Leak detection metrics

### Error Handling

The configuration includes comprehensive error handling:
- Validates JDBC URL presence
- Validates database type support
- Provides meaningful error messages
- Graceful fallback to defaults

### Testing Strategy



The system includes extensive unit tests covering:

- Database type detection

- Connection pool configuration

- Error scenarios

- Property resolution

- Database-specific optimizations



## Core Shared Components



This section documents the shared core components that provide foundational patterns for data access, validation, and API responses across the application.



### Repository Layer



#### UuidRepository Interface

A specialized repository interface that extends Spring Data JPA's `JpaRepository` to support UUID-based entity lookup alongside standard Long ID primary keys.



```java

@NoRepositoryBean

public interface UuidRepository<T> extends JpaRepository<T, Long> {

    Optional<T> findByUuid(UUID uuid);

}

```



**Purpose**: Enables entities to be retrieved by both their database primary key (Long) and their business identifier (UUID). This pattern provides:

- Public UUIDs for external API exposure

- Internal Long IDs for database efficiency

- Type-safe repository operations



#### RepositoryHelper Utility

A utility class providing standardized methods for entity retrieval with consistent error handling.



```java

public final class RepositoryHelper {

    public static <T, I> T findByIdOrThrow(

        JpaRepository<T, I> repository,

        I id,

        Class<T> entityClass) {

        // Returns entity or throws ResourceNotFoundException

    }

    

    public static <T> T findByUuidOrThrow(

        UuidRepository<T> repository,

        UUID uuid,

        Class<T> entityClass) {

        // Returns entity or throws ResourceNotFoundException

    }

}

```



**Key Features**:

- Consistent error messages including entity class name and identifier

- Reduces boilerplate code in service layers

- Type-safe with generic parameters

- Utility class pattern (cannot be instantiated)



### Validation Layer



#### ValidationHelper Utility

Provides comprehensive validation methods for common application concerns.



```mermaid

graph TD

    A[ValidationHelper] --> B[Pagination Validation]

    A --> C[Sort Direction Parsing]

    A --> D[ID Validation]

    A --> E[UUID Validation]

    A --> F[Sort Field Validation]

    

    B --> B1[Page ≥ 0]

    B --> B2[Size: 1-1000]

    

    C --> C1[ASC/DESC parsing]

    C --> C2[Default: ASC]

    

    D --> D1[Positive Long]

    D --> D2[Entity-specific messages]

    

    E --> E1[Non-null UUID]

    E --> E2[Entity-specific messages]

    

    F --> F1[Allowed fields check]

    F --> F2[Case-sensitive matching]

```



**Validation Methods**:

- `validatePaginationParameters(int page, int size)`: Ensures pagination bounds (page ≥ 0, size 1-1000)

- `parseSortDirection(String)`: Parses "ASC"/"DESC" strings to `Sort.Direction`

- `validateId(Long)` / `validateId(Long, String)`: Validates positive Long IDs

- `validateUuid(UUID)` / `validateUuid(UUID, String)`: Validates non-null UUIDs

- `validateSortBy(String, String...)`: Validates sort fields against allowed list



### Response Models



#### ApiResponse Record

Standardized API response wrapper for consistent client communication.



```java

public record ApiResponse<T>(

    Boolean success,

    T data,

    String message,

    Instant timestamp,

    String path

) {

    public static <T> ApiResponse<T> success(T data, String message, String path) { ... }

    public static <T> ApiResponse<T> error(String message, String path) { ... }

}

```



**Features**:

- `@JsonInclude(JsonInclude.Include.NON_NULL)`: Omits null fields from JSON

- Factory methods for success/error responses

- Automatic timestamp generation

- Path tracking for request correlation



#### PagedResponse Record

Specialized response for paginated data with comprehensive metadata.



```java

public record PagedResponse<T>(

    List<T> content,

    PageInfo page

) {

    public static <T> PagedResponse<T> of(Page<T> page) { ... }

    public static <T, R> PagedResponse<R> of(Page<T> page, Function<T, R> mapper) { ... }

    

    public record PageInfo(

        int number,

        int size,

        long totalElements,

        int totalPages,

        boolean first,

        boolean last,

        boolean hasNext,

        boolean hasPrevious

    ) { ... }

}

```



**Key Capabilities**:

- Direct conversion from Spring `Page` objects

- Support for DTO mapping via `Function` parameter

- Complete pagination metadata

- Consistent JSON structure across all paginated endpoints



### Service Contract



#### IGenericService Interface

Defines a standard CRUD contract for entity services supporting both Long ID and UUID operations.



```java

public interface IGenericService<T, K> {

    PagedResponse<K> getAll(int page, int size, String sortBy, String sortDirection);

    K getById(Long id);

    K getByUuid(UUID uuid);

    K save(T entity);

    K update(Long id, T entity);

    K updateByUuid(UUID uuid, T entity);

    void softDelete(Long id);

    void softDeleteByUuid(UUID uuid);

    void delete(Long id);

    void deleteByUuid(UUID uuid);

}

```



**Design Patterns**:

- **Dual Identifier Support**: All operations available for both Long IDs and UUIDs

- **Separation of Concerns**: Input type `T` vs. output type `K` allows for DTO transformation

- **Soft Delete Support**: Logical deletion alongside physical deletion

- **Pagination Standardization**: Consistent parameter ordering and types



### Testing Strategy



Comprehensive test coverage for core utilities:



1. **RepositoryHelperTest**: Validates entity retrieval with proper error handling

2. **ValidationHelperTest**: Tests all validation scenarios with edge cases

3. **ApiResponseTest**: Ensures response factory methods work correctly



**Test Patterns**:

- Utility class instantiation prevention

- Parameter validation with meaningful error messages

- Mock repository interactions

- Edge case coverage (null, empty, invalid values)



### Usage Example



```java

// Service implementation using shared components

@Service

public class UserService implements IGenericService<UserDTO, UserResponse> {

    

    private final UuidRepository<User> userRepository;

    

    @Override

    public UserResponse getByUuid(UUID uuid) {

        ValidationHelper.validateUuid(uuid, "User");

        User user = RepositoryHelper.findByUuidOrThrow(userRepository, uuid, User.class);

        return UserMapper.toResponse(user);

    }

    

    @Override

    public PagedResponse<UserResponse> getAll(int page, int size, String sortBy, String sortDirection) {

        ValidationHelper.validatePaginationParameters(page, size);

        ValidationHelper.validateSortBy(sortBy, "name", "email", "createdAt");

        Sort.Direction direction = ValidationHelper.parseSortDirection(sortDirection);

        

        Page<User> users = userRepository.findAll(

            PageRequest.of(page, size, Sort.by(direction, sortBy))

        );

        

        return PagedResponse.of(users, UserMapper::toResponse);

    }

}

```



This shared core establishes consistent patterns across the application, reducing boilerplate and ensuring uniform behavior for common operations.
