# Business Flows

This document visualizes core business logic using Sequence Diagrams.

## Core Flows
<!-- Add Mermaid sequence diagrams for core logic -->
