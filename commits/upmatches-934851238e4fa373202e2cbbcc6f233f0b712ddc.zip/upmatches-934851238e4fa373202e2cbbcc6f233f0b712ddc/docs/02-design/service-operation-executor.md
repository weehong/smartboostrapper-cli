# Service Operation Executor Pattern

## Overview
The `ServiceOperationExecutor` provides a centralized, consistent approach to executing service operations with comprehensive error handling, logging, and monitoring capabilities.

## Design Pattern

### Unified Execution Flow
```mermaid
flowchart TD
    A[Start Operation] --> B[Generate/Get Trace ID]
    B --> C[Log Operation Start]
    C --> D[Execute Operation]
    D --> E{Success?}
    E -->|Yes| F[Log Success]
    F --> G[Return Result]
    
    E -->|No| H{Exception Type?}
    H -->|Database| I[Handle Database Exception]
    H -->|External Service| J[Handle RestClient Exception]
    H -->|File| K[Handle File Exception]
    H -->|Resource Not Found| L[Handle Resource Not Found]
    H -->|Programmer Error| M[Bubble Up]
    H -->|Other Runtime| N[Wrap in Generic Exception]
    
    I --> O[Map to Business Exception]
    J --> P[Create ExternalServiceException]
    K --> Q[Wrap in Factory Exception]
    L --> R[Re-throw As-Is]
    M --> R
    N --> Q
    
    O --> S[Log Error]
    P --> S
    Q --> S
    R --> S
    
    S --> T[Throw Mapped Exception]
```

## Core Components

### OperationStatus Enum
Defines the type of operation being performed:
- `RETRIEVE`: Read operations
- `SAVE`: Create operations
- `UPDATE`: Update operations
- `DELETE`: Delete operations
- `OTHER`: Miscellaneous operations

### ExceptionFactory Interface
```java
@FunctionalInterface
public interface ExceptionFactory {
    RuntimeException create(String message, Throwable cause);
}
```
Allows custom exception creation strategies.

### ServiceOperationExecutorConstant
Configuration constants:
- `MAX_RESPONSE_BODY_SIZE`: 10,000 bytes (10KB)
- `TRUNCATION_INDICATOR`: "\n\n--- RESPONSE TRUNCATED (exceeded 10KB limit) ---"
- `MDC_REQUEST_ID_KEY`: "requestId"

## Execution Methods

### execute() - For Operations Returning Values
```java
public static <T> T execute(
    Supplier<T> operation,
    OperationStatus operationType,
    ExceptionFactory exceptionFactory
)
```

### executeVoid() - For Void Operations
```java
public static void executeVoid(
    Runnable operation,
    OperationStatus operationType,
    ExceptionFactory exceptionFactory
)
```

## Exception Mapping Strategy

### Database Exceptions
| Exception Type | Description | Message |
|----------------|-------------|----------|
| `EntityNotFoundException` | Resource doesn't exist | Custom message based on operation type |
| `EntityExistsException` | Duplicate resource | "Entity already exists" |
| `DataIntegrityViolationException` | Constraint violation | Operation-specific constraint message |
| `OptimisticLockingFailureException` | Concurrent modification | "Concurrent modification detected - please retry" |
| `DeadlockLoserDataAccessException` | Database deadlock | "Database deadlock detected - please retry" |
| `CannotAcquireLockException` | Resource locked | "Cannot acquire database lock - resource may be in use" |

### External Service Exceptions
| Exception Type | Description | Message |
|----------------|-------------|----------|
| `HttpStatusCodeException` | External service error | Includes status code and truncated response body |
| `ResourceAccessException` | Service unavailable | "External service unavailable" |

### Programmer Errors (Bubbled Up)
- `NullPointerException`
- `IllegalStateException`
- `UnsupportedOperationException`
- `ClassCastException`
- `IndexOutOfBoundsException`
- `ArithmeticException`
- `NumberFormatException`

## Logging Strategy

### Structured Logging
```json
{
  "timestamp": "2024-01-15T10:30:00Z",
  "level": "ERROR",
  "requestId": "550e8400-e29b-41d4-a716-446655440000",
  "operation": "SAVE",
  "message": "Database exception occurred",
  "exceptionType": "DataIntegrityViolationException"
}
```

### Log Levels
- **DEBUG**: Operation start/end, trace ID management
- **WARN**: Validation failures, expected business errors
- **ERROR**: System failures, unexpected exceptions

## Configuration

### Trace ID Management
```java
private static String getOrCreateTraceId() {
    String existingTraceId = MDC.get(MDC_REQUEST_ID_KEY);
    
    if (existingTraceId != null && !existingTraceId.isBlank()) {
        return existingTraceId;
    }
    
    String newTraceId = randomUUID().toString();
    MDC.put(MDC_REQUEST_ID_KEY, newTraceId);
    return newTraceId;
}
```

### Response Body Truncation
Large external service responses are truncated to 10KB to prevent memory issues and log flooding.

## Usage Examples

### Basic Usage
```java
public User findUserById(Long userId) {
    return ServiceOperationExecutor.execute(
        () -> userRepository.findById(userId)
            .orElseThrow(() -> new ResourceNotFoundException("User not found")),
        OperationStatus.RETRIEVE,
        (message, cause) -> new ServiceException(message, cause)
    );
}
```

### Void Operation
```java
public void deleteUser(Long userId) {
    ServiceOperationExecutor.executeVoid(
        () -> {
            User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
            userRepository.delete(user);
        },
        OperationStatus.DELETE,
        (message, cause) -> new ServiceException(message, cause)
    );
}
```

### Custom Exception Factory
```java
ExceptionFactory factory = (message, cause) -> 
    new BusinessException("USER_OPERATION_FAILED", message, cause);

ServiceOperationExecutor.execute(
    () -> userService.complexOperation(),
    OperationStatus.UPDATE,
    factory
);
```

## Best Practices

1. **Always Provide Operation Type**: Helps with logging and exception mapping
2. **Use Appropriate Exception Factory**: Create meaningful business exceptions
3. **Handle Programmer Errors Separately**: Let NPEs and other bugs bubble up
4. **Include Trace IDs**: Ensure correlation across distributed systems
5. **Monitor Database Exception Rates**: Use metrics to track persistence layer health
6. **Test Exception Paths**: Ensure all exception types are properly mapped
