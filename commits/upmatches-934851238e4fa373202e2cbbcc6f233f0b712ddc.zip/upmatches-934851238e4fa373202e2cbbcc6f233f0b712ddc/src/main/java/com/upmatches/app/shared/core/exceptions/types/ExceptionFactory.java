package com.upmatches.app.shared.core.exceptions.types;

@FunctionalInterface
public interface ExceptionFactory {

    RuntimeException create(String message, Throwable cause);

}
